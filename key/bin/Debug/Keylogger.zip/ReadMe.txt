F3--> EMpieza Escuchar
F4-->para detener ejecucion

Los codigos se guardan en D:\barcode.csv